#!/usr/bin/env python
# coding: utf-8

# In[3]:


def fun1():
    print('Fun1',__name__)
if __name__=='__main__':
    fun1()


# In[ ]:




